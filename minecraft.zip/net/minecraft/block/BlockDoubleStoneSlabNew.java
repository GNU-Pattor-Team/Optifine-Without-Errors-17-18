package net.minecraft.block;

public class BlockDoubleStoneSlabNew extends BlockStoneSlabNew
{
    public boolean isDouble()
    {
        return true;
    }
}
