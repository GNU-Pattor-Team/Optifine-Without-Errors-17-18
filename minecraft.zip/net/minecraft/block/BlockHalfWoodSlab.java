package net.minecraft.block;

public class BlockHalfWoodSlab extends BlockWoodSlab
{
    public boolean isDouble()
    {
        return false;
    }
}
